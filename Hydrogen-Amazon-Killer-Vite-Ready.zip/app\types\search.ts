export interface PredictiveSearchResult {
    products: Array<{
        id: string;
        title: string;
        handle: string;
        priceRange: {
            minVariantPrice: {
                amount: string;
                currencyCode: string;
            }
        };
        images: {
            nodes: Array<{
                url: string;
                altText?: string;
            }>
        };
        tags: string[];
    }>;
    collections: any[];
    pages: any[];
}
