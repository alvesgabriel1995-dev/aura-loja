import { Suspense } from 'react';
import { Await, useFetcher } from '@remix-run/react';
import { Money, Image } from '@shopify/hydrogen';

// Visual Free Shipping Threshold
const FREE_SHIPPING_THRESHOLD = 500.0;

export function CartDrawer({ isOpen, onClose, cart }: { isOpen: boolean; onClose: () => void; cart: any }) {
    if (!isOpen) return null;

    const cost = cart?.cost?.subtotalAmount?.amount ? parseFloat(cart.cost.subtotalAmount.amount) : 0;
    const progress = Math.min((cost / FREE_SHIPPING_THRESHOLD) * 100, 100);
    const remaining = FREE_SHIPPING_THRESHOLD - cost;

    return (
        <div className="fixed inset-0 z-50 flex justify-end">
            {/* Backdrop */}
            <div
                className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
                onClick={onClose}
            />

            {/* Drawer Panel */}
            <aside className="relative w-full max-w-md bg-surface border-l border-white/5 shadow-2xl h-full flex flex-col transform transition-transform duration-300 animate-slide-left">

                {/* Header */}
                <div className="p-6 border-b border-white/5 flex justify-between items-center">
                    <h2 className="text-2xl font-display font-bold text-white">Seu Carrinho</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
                        <span className="sr-only">Fechar</span>
                        &#10005;
                    </button>
                </div>

                {/* Free Shipping Progress Bar */}
                <div className="px-6 py-4 bg-white/5">
                    <div className="flex justify-between text-sm mb-2">
                        <span className="text-gray-300">Meta de Frete Grátis</span>
                        <span className="text-primary font-bold">{progress >= 100 ? 'Frete Grátis!' : `Faltam R$ ${remaining.toFixed(2)}`}</span>
                    </div>
                    <div className="w-full bg-gray-800 rounded-full h-2 overflow-hidden">
                        <div
                            className="bg-gradient-to-r from-primary to-green-400 h-full rounded-full transition-all duration-500 ease-out"
                            style={{ width: `${progress}%` }}
                        />
                    </div>
                </div>

                {/* Cart Items */}
                <div className="flex-1 overflow-y-auto p-6 space-y-6">
                    {cart?.lines?.nodes?.length > 0 ? (
                        cart.lines.nodes.map((line: any) => (
                            <CartLineItem key={line.id} line={line} />
                        ))
                    ) : (
                        <div className="text-center py-20 text-gray-500">
                            Seu carrinho está vazio.
                        </div>
                    )}

                    {/* Upsell Section / One-Click Add */}
                    <div className="mt-8 pt-8 border-t border-white/10">
                        <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4">Complete o Look</h3>
                        <div className="flex space-x-4 overflow-x-auto pb-4 no-scrollbar">
                            {/* Mock Upsell Products */}
                            {[1, 2, 3].map((i) => (
                                <div key={i} className="min-w-[120px] bg-white/5 rounded-xl p-3 hover:bg-white/10 transition-colors cursor-pointer group">
                                    <div className="aspect-square bg-gray-700 rounded-lg mb-2 overflow-hidden">
                                        <div className="w-full h-full bg-gray-600 animate-pulse group-hover:scale-110 transition-transform"></div>
                                    </div>
                                    <p className="text-xs font-medium text-white line-clamp-1">Upsell Item {i}</p>
                                    <p className="text-xs text-secondary mt-1">R$ 49,90</p>
                                    <button className="mt-2 w-full py-1 text-[10px] font-bold bg-white text-black rounded hover:bg-gray-200">
                                        ADD +
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Footer / Checkout */}
                <div className="p-6 border-t border-white/5 bg-surface/50 backdrop-blur">
                    <div className="flex justify-between items-center mb-4">
                        <span className="text-lg text-gray-400">Total</span>
                        <span className="text-2xl font-bold text-white">
                            <Money data={cart?.cost?.totalAmount || { amount: '0', currencyCode: 'BRL' }} />
                        </span>
                    </div>
                    <button className="w-full py-4 bg-primary text-black font-bold text-lg rounded-full hover:shadow-[0_0_20px_rgba(187,247,208,0.3)] transition-all">
                        Checkout Seguro
                    </button>
                </div>

            </aside>
        </div>
    );
}

function CartLineItem({ line }: { line: any }) {
    return (
        <div className="flex items-center space-x-4">
            <div className="w-20 h-20 rounded-xl overflow-hidden bg-gray-800 border border-white/5">
                <Image data={line.merchandise.image} className="w-full h-full object-cover" />
            </div>
            <div className="flex-1">
                <h4 className="font-medium text-white">{line.merchandise.product.title}</h4>
                <p className="text-sm text-gray-400">{line.merchandise.title}</p>
                <div className="flex items-center justify-between mt-2">
                    <p className="font-mono text-sm"><Money data={line.cost.totalAmount} /></p>
                    {/* Quantity Controls Mock */}
                    <div className="flex items-center bg-white/5 rounded-full px-2">
                        <button className="px-2 text-gray-400">-</button>
                        <span className="text-xs font-bold text-white">{line.quantity}</span>
                        <button className="px-2 text-gray-400">+</button>
                    </div>
                </div>
            </div>
        </div>
    );
}
