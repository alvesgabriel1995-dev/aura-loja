import { useRef, useEffect, useState } from 'react';
import { useFetcher } from '@remix-run/react';
import type { PredictiveSearchResult } from '~/types/search'; // Assuming types generic

export function PredictiveSearch() {
    const fetcher = useFetcher();
    const [query, setQuery] = useState('');
    const [isOpen, setIsOpen] = useState(false);
    const inputRef = useRef<HTMLInputElement>(null);

    // Efficient Debounce
    useEffect(() => {
        const timer = setTimeout(() => {
            if (query.length > 2) {
                fetcher.load(`/search/suggest?q=${query}`);
            }
        }, 300); // 300ms debounce
        return () => clearTimeout(timer);
    }, [query]);

    const results = fetcher.data as any; // Typed as any for template brevity, strictly would use generated Types

    return (
        <div className="relative w-full max-w-2xl mx-auto z-50">
            <div className={`
        relative flex items-center bg-surface/80 backdrop-blur-xl border border-white/10 rounded-full px-6 py-4
        focus-within:ring-2 focus-within:ring-primary/50 transition-all duration-300 shadow-2xl
      `}>
                <svg className="w-6 h-6 text-gray-400 mr-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                <input
                    ref={inputRef}
                    type="text"
                    placeholder="O que você procura hoje?"
                    className="w-full bg-transparent border-none text-white placeholder-gray-500 focus:ring-0 text-lg outline-none"
                    value={query}
                    onChange={(e) => {
                        setQuery(e.target.value);
                        setIsOpen(true);
                    }}
                    onFocus={() => setIsOpen(true)}
                />
                {fetcher.state === 'loading' && (
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white ml-2"></div>
                )}
            </div>

            {/* Semantic Results Dropdown */}
            {isOpen && (query.length > 0 || results) && (
                <div className="absolute top-full mt-4 w-full bg-[#0a0a0a]/95 backdrop-blur-2xl rounded-2xl border border-white/5 shadow-2xl overflow-hidden animate-fade-in p-4">

                    {!query && (
                        <div className="p-4">
                            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-4">Trending Now</h3>
                            <div className="flex flex-wrap gap-2">
                                {['Smartwatch', 'Neon Headphones', 'Cyber Deck'].map(term => (
                                    <button key={term} className="px-4 py-2 bg-white/5 hover:bg-white/10 rounded-full text-sm text-gray-300 transition-colors">
                                        Running {term} &#8599;
                                    </button>
                                ))}
                            </div>
                        </div>
                    )}

                    {results?.products && (
                        <div>
                            <h3 className="text-xs font-bold text-primary mb-3 px-2">Produtos Sugeridos</h3>
                            <ul className="space-y-2">
                                {results.products.map((p: any) => (
                                    <li key={p.id} className="group flex items-center p-2 rounded-xl hover:bg-white/5 cursor-pointer transition-colors">
                                        <div className="w-16 h-16 rounded-lg overflow-hidden relative bg-gray-800 mr-4">
                                            <img src={p.images.nodes[0]?.url} alt={p.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                                        </div>
                                        <div>
                                            <p className="font-medium text-white group-hover:text-primary transition-colors">{p.title}</p>
                                            <p className="text-sm text-gray-400">{p.priceRange.minVariantPrice.amount} BRL</p>
                                        </div>
                                        {p.tags.includes('bestseller') && (
                                            <span className="ml-auto text-[10px] bg-accent/20 text-accent px-2 py-1 rounded-full font-bold">
                                                BEST CHOICE
                                            </span>
                                        )}
                                    </li>
                                ))}
                            </ul>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}
