/// <reference types="@shopify/remix-oxygen" />
/// <reference types="@shopify/hydrogen/storefront-api-types" />

import type { Storefront } from '@shopify/hydrogen';

declare global {
    /**
     * The global `Env` interface for Oxygen environment variables.
     */
    interface Env {
        SESSION_SECRET: string;
        PUBLIC_STOREFRONT_API_TOKEN: string;
        PRIVATE_STOREFRONT_API_TOKEN: string;
        PUBLIC_STORE_DOMAIN: string;
        PUBLIC_STOREFRONT_ID: string;
    }
}

declare module '@shopify/remix-oxygen' {
    /**
     * Be careful not to add any sensitive data to the AppLoadContext.
     */
    export interface AppLoadContext {
        storefront: Storefront;
        env: Env;
        waitUntil: ExecutionContext['waitUntil'];
        executionContext: ExecutionContext;
    }
}
