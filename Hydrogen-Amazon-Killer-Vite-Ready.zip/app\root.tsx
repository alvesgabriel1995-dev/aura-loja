import {
    Links,
    Meta,
    Outlet,
    Scripts,
    ScrollRestoration,
    useLoaderData,
} from '@remix-run/react';
import type { LinksFunction, LoaderFunctionArgs } from '@shopify/remix-oxygen';
import { cssBundleHref } from '@remix-run/css-bundle';
import appStyles from './styles/app.css';

// Components
import { CartDrawer } from './components/cart/CartDrawer';
import { PredictiveSearch } from './components/search/PredictiveSearch';
import { useState } from 'react';

// SEO & Performance
export const links: LinksFunction = () => [
    { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
    { rel: 'preconnect', href: 'https://fonts.gstatic.com', crossOrigin: 'anonymous' },
    { rel: 'stylesheet', href: 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&family=Outfit:wght@400;700&display=swap' }, // font-display: swap for CLS
    { rel: 'stylesheet', href: appStyles },
    ...(cssBundleHref ? [{ rel: 'stylesheet', href: cssBundleHref }] : []),
];

export const meta = () => {
    return [
        { title: "Hydrogen | Amazon Killer" },
        { name: "description", content: "A high-performance headless commerce experience." },
        { viewport: "width=device-width, initial-scale=1" },
    ];
};

export async function loader({ context }: LoaderFunctionArgs) {
    // In a real app, you'd fetch the cart here using context.storefront
    const cart = {
        id: 'gid://shopify/Cart/123',
        lines: { nodes: [] },
        cost: { subtotalAmount: { amount: '150.00', currencyCode: 'BRL' }, totalAmount: { amount: '150.00', currencyCode: 'BRL' } }
    };
    return { cart, ENV: context.env };
}

export default function App() {
    const { cart, ENV } = useLoaderData<typeof loader>();
    const [isCartOpen, setIsCartOpen] = useState(false);

    return (
        <html lang="pt-BR">
            <head>
                <meta charSet="utf-8" />
                <Meta />
                <Links />
            </head>
            <body className="bg-background text-white selection:bg-primary selection:text-black">

                {/* Cinematic Header */}
                <header className="fixed top-0 left-0 right-0 z-40 px-6 py-4 flex items-center justify-between pointer-events-none">
                    {/* Logo */}
                    <div className="pointer-events-auto transition-transform hover:scale-110">
                        <span className="font-display font-bold text-2xl tracking-tighter text-white">
                            AURA<span className="text-primary">.</span>
                        </span>
                    </div>

                    {/* Central Search */}
                    <div className="pointer-events-auto hidden md:block w-96">
                        <PredictiveSearch />
                    </div>

                    {/* Icons / Cart Trigger */}
                    <div className="pointer-events-auto flex items-center space-x-6">
                        <button
                            className="relative group p-2"
                            onClick={() => setIsCartOpen(true)}
                        >
                            <div className="absolute inset-0 bg-white/10 rounded-full scale-0 group-hover:scale-100 transition-transform"></div>
                            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                            </svg>
                            {/* Cart Badge */}
                            <span className="absolute top-1 right-1 w-2 h-2 bg-accent rounded-full animate-bounce"></span>
                        </button>
                    </div>
                </header>

                {/* Global Cart Drawer */}
                <CartDrawer isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} cart={cart} />

                {/* Main Content Render */}
                <main className="relative z-0 min-h-screen">
                    <Outlet />
                </main>

                <ScrollRestoration />
                <Scripts />
            </body>
        </html>
    );
}
