import { Link } from '@remix-run/react';
import { Image, Money } from '@shopify/hydrogen';

interface ProductCardProps {
    product: any;
    loading?: 'eager' | 'lazy';
}

export function ProductCard({ product, loading = 'lazy' }: ProductCardProps) {
    const variant = product.variants.nodes[0];

    return (
        <Link to={`/products/${product.handle}`} className="group relative block overflow-hidden rounded-xl bg-white/5 border border-white/5 hover:border-primary/50 transition-all duration-300 hover:shadow-[0_0_30px_rgba(187,247,208,0.1)]">
            <div className="aspect-[4/5] overflow-hidden bg-gray-800">
                <Image
                    data={variant.image}
                    aspectRatio="4/5"
                    loading={loading} // LCP Optimization: Use 'eager' for above-the-fold
                    sizes="(min-width: 45em) 400px, 100vw"
                    className="h-full w-full object-cover object-center transition-transform duration-700 group-hover:scale-110"
                />

                {/* Quick Add Overlay */}
                <div className="absolute inset-x-0 bottom-0 translate-y-full px-4 pb-4 transition-transform duration-300 group-hover:translate-y-0">
                    <button className="w-full rounded-full bg-white py-2 text-xs font-bold text-black hover:bg-primary transition-colors">
                        Quick Add +
                    </button>
                </div>
            </div>

            <div className="p-4">
                <h3 className="text-sm font-medium text-white group-hover:text-primary transition-colors">
                    {product.title}
                </h3>
                <div className="mt-1 flex items-center justify-between">
                    <span className="text-sm text-gray-400">
                        <Money data={variant.price} />
                    </span>
                </div>
            </div>
        </Link>
    );
}
