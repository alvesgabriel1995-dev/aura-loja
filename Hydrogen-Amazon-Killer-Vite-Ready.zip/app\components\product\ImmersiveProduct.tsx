import { useState, useEffect } from 'react';
import { Image, Money } from '@shopify/hydrogen';
import type { Product } from '@shopify/hydrogen/storefront-api-types';

interface ImmersiveProductProps {
    product: Product;
}

export function ImmersiveProduct({ product }: ImmersiveProductProps) {
    const [selectedVariant, setSelectedVariant] = useState(product.variants.nodes[0]);
    const [isAdding, setIsAdding] = useState(false);

    // Simulated Haptic Feedback (Visual)
    const handleAddToCart = () => {
        setIsAdding(true);
        // Trigger navigator.vibrate if available for mobile haptics
        if (typeof navigator !== 'undefined' && navigator.vibrate) {
            navigator.vibrate(50);
        }

        setTimeout(() => setIsAdding(false), 500);
        // Add to cart logic would go here (useFetcher)
    };

    return (
        <div className="relative h-screen w-full overflow-hidden bg-background text-white">
            {/* Cinematic Video Background - Changes based on variant color/metafield */}
            <div className="absolute inset-0 z-0">
                <video
                    autoPlay
                    loop
                    muted
                    playsInline
                    className="w-full h-full object-cover opacity-60 transition-opacity duration-700 ease-in-out"
                    key={selectedVariant?.id} // Forces re-render/fade on change
                    poster={selectedVariant?.image?.url}
                >
                    {/* In production, use a metafield for the video URL */}
                    <source src="https://cdn.shopify.com/videos/c/vp/.../placeholder.mp4" type="video/mp4" />
                </video>
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />
            </div>

            {/* Floating Glass Panel Product Details */}
            <div className="relative z-10 flex h-full flex-col justify-end pb-12 px-6 md:justify-center md:px-20 lg:w-1/2">
                <div className="glass-panel p-8 rounded-2xl animate-slide-up">

                    {/* Brand / Collection Tag */}
                    <span className="text-primary text-xs font-bold tracking-widest uppercase mb-2 block">
                        New Collection 2026
                    </span>

                    <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-4 text-gradient">
                        {product.title}
                    </h1>

                    <div className="flex items-baseline space-x-4 mb-6">
                        <span className="text-3xl font-light">
                            <Money data={selectedVariant.price} />
                        </span>
                        {selectedVariant.compareAtPrice && (
                            <span className="text-lg text-gray-500 line-through">
                                <Money data={selectedVariant.compareAtPrice} />
                            </span>
                        )}
                    </div>

                    {/* Logistics "Prime" Killer */}
                    <div className="flex items-center space-x-2 mb-8 bg-green-900/30 w-fit px-3 py-1 rounded-full border border-green-500/30">
                        <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span>
                        <span className="text-sm font-medium text-green-300">
                            Chega <span className="font-bold text-white">Amanhã</span> (São Paulo)
                        </span>
                    </div>

                    {/* Variant Selectors (Minimalist) */}
                    <div className="flex space-x-4 mb-8">
                        {product.variants.nodes.map((variant) => (
                            <button
                                key={variant.id}
                                onClick={() => setSelectedVariant(variant)}
                                className={`w-10 h-10 rounded-full border-2 transition-all ${selectedVariant.id === variant.id ? 'border-primary scale-110 shadow-[0_0_15px_rgba(187,247,208,0.5)]' : 'border-transparent opacity-80'
                                    }`}
                                style={{ backgroundColor: variant.title.toLowerCase().includes('black') ? 'black' : variant.title.toLowerCase() }} // Placeholder color logic
                                aria-label={variant.title}
                            />
                        ))}
                    </div>

                    {/* Action Button */}
                    <button
                        onClick={handleAddToCart}
                        className={`
              w-full md:w-auto px-8 py-4 bg-white text-black font-bold text-lg rounded-full 
              transition-all duration-200 transform hover:scale-105 active:scale-95
              flex items-center justify-center space-x-2
              ${isAdding ? 'bg-primary scale-95' : 'hover:shadow-[0_0_20px_rgba(255,255,255,0.4)]'}
            `}
                    >
                        <span>{isAdding ? 'Adicionando...' : 'Adicionar à Sacola'}</span>
                        {!isAdding && (
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                            </svg>
                        )}
                    </button>
                </div>
            </div>
        </div>
    );
}
