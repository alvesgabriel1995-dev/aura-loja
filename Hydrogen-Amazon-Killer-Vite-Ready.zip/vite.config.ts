import { defineConfig } from 'vite';
import { hydrogen } from '@shopify/hydrogen/vite';
import { oxygen } from '@shopify/remix-oxygen/vite';
import { remix } from '@remix-run/dev/vite';
import tsconfigPaths from 'vite-tsconfig-paths';

export default defineConfig({
    plugins: [
        hydrogen(),
        oxygen(),
        remix({
            presets: [hydrogen.preset()],
            future: {
                v3_fetcherPersist: true,
                v3_relativeSplatPath: true,
                v3_throwAbortReason: true,
            },
        }),
        tsconfigPaths(),
    ],
    ssr: {
        optimizeDeps: {
            include: []
        }
    }
});
