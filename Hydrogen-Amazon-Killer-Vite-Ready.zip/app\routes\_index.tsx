import { defer, type LoaderFunctionArgs } from '@shopify/remix-oxygen';
import { Await, useLoaderData, type MetaFunction } from '@remix-run/react';
import { Suspense } from 'react';
import { ImmersiveProduct } from '~/components/product/ImmersiveProduct';
import { ProductCard } from '~/components/product/ProductCard';

export const meta: MetaFunction = () => {
    return [
        { title: "AURA | The Amazon Killer" },
        { name: "description", content: "Experience the next generation of commerce." },
    ];
};

export async function loader({ context }: LoaderFunctionArgs) {
    const { storefront } = context;

    // High-Performance Query: Fetch Hero Product + Trending Drops in parallel
    const data = await storefront.query(`#graphql
    fragment ProductCard on Product {
      id
      title
      handle
      variants(first: 1) {
        nodes {
          id
          price {
            amount
            currencyCode
          }
          compareAtPrice {
            amount
            currencyCode
          }
          image {
            url
            altText
            width
            height
          }
        }
      }
    }

    query HomepageContent($country: CountryCode, $language: LanguageCode)
    @inContext(country: $country, language: $language) {
      hero: products(first: 1, query: "tag:hero OR tag:featured") {
        nodes {
          ...ProductCard
          description
        }
      }
      trending: products(first: 4, sortKey: CREATED_AT, reverse: true) {
        nodes {
          ...ProductCard
        }
      }
    }
  `);

    return defer({
        heroProduct: data.hero.nodes[0] || null,
        trendingProducts: data.trending.nodes,
    });
}

export default function Index() {
    const { heroProduct, trendingProducts } = useLoaderData<typeof loader>();

    return (
        <div>
            {heroProduct ? (
                <ImmersiveProduct product={heroProduct} />
            ) : (
                <div className="h-screen flex items-center justify-center bg-black">
                    <h1 className="text-4xl font-display text-white">AURA<span className="text-primary">.</span></h1>
                </div>
            )}

            <section className="py-20 px-6 max-w-7xl mx-auto">
                <div className="flex justify-between items-end mb-10">
                    <h2 className="text-3xl font-display font-bold text-gradient">Trending Drops</h2>
                    <a href="/collections/all" className="text-sm font-bold text-primary hover:underline">View All &rarr;</a>
                </div>

                <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
                    {trendingProducts.map((product: any, i: number) => (
                        <ProductCard
                            key={product.id}
                            product={product}
                            loading={i < 2 ? 'eager' : 'lazy'}
                        />
                    ))}
                </div>
            </section>

            <section className="py-20 px-6 max-w-7xl mx-auto">
                <h2 className="text-3xl font-display font-bold mb-10 text-center text-gradient">Why Choose AURA?</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {[
                        { title: 'Zero Gravity Shipping', desc: 'Drone delivery in 2 hours for select cities.' },
                        { title: 'Try Before You Buy', desc: 'AR fitting in your living room.' },
                        { title: 'Neural Returns', desc: 'Instant refund, no questions asked.' }
                    ].map((feature, i) => (
                        <div key={i} className="p-8 rounded-2xl bg-white/5 border border-white/5 hover:border-primary/50 transition-colors">
                            <h3 className="text-xl font-bold mb-4 text-primary">{feature.title}</h3>
                            <p className="text-gray-400">{feature.desc}</p>
                        </div>
                    ))}
                </div>
            </section>
        </div>
    );
}
