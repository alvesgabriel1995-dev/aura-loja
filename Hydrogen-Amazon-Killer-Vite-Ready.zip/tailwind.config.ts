import type { Config } from 'tailwindcss';

export default {
    content: ['./app/**/*.{js,jsx,ts,tsx}'],
    theme: {
        extend: {
            colors: {
                background: '#050505', // Deep luxurious black
                surface: '#121212', // Slightly lighter for cards
                primary: '#BBF7D0', // Soft neon green (premium sustainable vibe)
                secondary: '#A78BFA', // Soft neon purple
                accent: '#F472B6', // Neon pink for CTAs
                'glass-border': 'rgba(255, 255, 255, 0.1)',
                'glass-bg': 'rgba(255, 255, 255, 0.05)',
            },
            fontFamily: {
                sans: ['"Geist Sans"', '"Inter"', 'sans-serif'],
                display: ['"Geist Sans"', 'sans-serif'],
            },
            animation: {
                'fade-in': 'fadeIn 0.5s ease-out',
                'slide-up': 'slideUp 0.5s ease-out',
                'subtle-pulse': 'subtlePulse 2s infinite',
            },
            keyframes: {
                fadeIn: {
                    '0%': { opacity: '0' },
                    '100%': { opacity: '1' },
                },
                slideUp: {
                    '0%': { transform: 'translateY(10px)', opacity: '0' },
                    '100%': { transform: 'translateY(0)', opacity: '1' },
                },
                subtlePulse: {
                    '0%, 100%': { opacity: '1' },
                    '50%': { opacity: '0.8' },
                },
            },
            backdropBlur: {
                xs: '2px',
            }
        },
    },
    plugins: [
        require('@tailwindcss/typography'),
    ],
} satisfies Config;
