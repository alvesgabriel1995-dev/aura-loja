import { createStorefrontClient } from '@shopify/hydrogen';
import { createRequestHandler } from '@shopify/remix-oxygen';
// @ts-ignore
import * as remixBuild from 'virtual:remix/server-build';

export default {
    async fetch(
        request: Request,
        env: Env,
        executionContext: ExecutionContext,
    ): Promise<Response> {
        try {
            // 1. Create the Storefront Client (with Fallback to Mock.shop for instant start)
            const { storefront } = createStorefrontClient({
                cache: await caches.open('hydrogen'),
                waitUntil: executionContext.waitUntil,
                i18n: { language: 'PT', country: 'BR' },
                // Fallback to mock.shop if no keys are present
                publicStorefrontToken: env.PUBLIC_STOREFRONT_API_TOKEN || '3b580e70970c4528da70c98e097c2fa0',
                privateStorefrontToken: env.PRIVATE_STOREFRONT_API_TOKEN,
                storeDomain: env.PUBLIC_STORE_DOMAIN || 'mock.shop',
                storefrontId: env.PUBLIC_STOREFRONT_ID,
                // @ts-ignore
                storefrontHeaders: {
                    requestGroupId: request.headers.get('request-id'),
                    buyerIp: request.headers.get('x-forwarded-for') || undefined,
                    cookie: request.headers.get('cookie'),
                },
            });

            // 2. Create the Remix Request Handler
            const handleRequest = createRequestHandler({
                build: remixBuild,
                mode: process.env.NODE_ENV,
                getLoadContext: () => ({
                    storefront,
                    env,
                    waitUntil: executionContext.waitUntil,
                    executionContext,
                }),
            });

            // 3. Handle the Request
            return await handleRequest(request);
        } catch (error) {
            console.error(error);
            return new Response('An unexpected error occurred', { status: 500 });
        }
    },
};
